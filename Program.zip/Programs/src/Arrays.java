
public class Arrays {

	public static void main(String[] args) {
		int[] a = new int[5];
		a[1] = 20;
		
		for (int num : a) {
			System.out.println(num);
		}
	}

}
