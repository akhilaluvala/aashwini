package a;

public class AnotherAccessClass {

	public static void main(String[] args) {
		
		AccessModifiersOne one = new AccessModifiersOne();
		one.publicMethod();
		//one.privateMethod();
		one.protectedMethod();
		one.packageFriendlyMethod();
		
	}
}
























