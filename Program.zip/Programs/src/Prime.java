
public class Prime {

	public static void normalArray() {

		for (int i = 1; i <= 100; i++) {
			int count = 0;
			for (int j = 1; j < i; j++) {
				if (i % j == 0)
					count++;
			}
			if (count < 2) {
				System.out.print(i + " ");
			}
		}
		System.out.println();
	}
	
	public static void alternativePrime() {
		for (int i = 1; i <= 100; i++) {
			int count = 0;
			for (int j = 1; j < i; j++) {
				if (i % j == 0)
					count++;
			}
			if (count < 2) {
				System.out.print(i + " ");
			}
		}
		System.out.println();
	}

	public static void main(String[] args) {

		Prime.normalArray();
		Prime.alternativePrime();
	}

}
